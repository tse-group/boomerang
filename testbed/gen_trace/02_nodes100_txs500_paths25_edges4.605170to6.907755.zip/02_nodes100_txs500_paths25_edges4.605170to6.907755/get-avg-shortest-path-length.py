#! /usr/bin/env python3

import sys

f = open(sys.argv[1], 'r')

shortest_paths = {}

for l in f.readlines():
	l = l.strip()
	nid_from, nid_to, path = l.split(',', 2)
	path_split = path.split(',')
	assert nid_from == path_split[0]
	assert nid_to == path_split[-1]

	k = (nid_from, nid_to)
	if not k in shortest_paths.keys():
		shortest_paths[k] = 1234567890

	shortest_paths[k] = min(shortest_paths[k], len(path_split) - 1)

print(len(shortest_paths))

print(1./len(shortest_paths) * sum([ v for (k, v) in shortest_paths.items() ]))
